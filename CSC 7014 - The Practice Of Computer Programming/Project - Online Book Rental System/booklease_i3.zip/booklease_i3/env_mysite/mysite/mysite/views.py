from django.http import HttpResponse  

def hello(request):
    return HttpResponse("Hey There !! This is my first website !! Hey Arnika, How are you ???")