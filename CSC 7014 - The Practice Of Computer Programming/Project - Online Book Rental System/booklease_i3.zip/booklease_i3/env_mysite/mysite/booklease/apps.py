from django.apps import AppConfig


class BookleaseConfig(AppConfig):
    name = 'booklease'
